<?php 
$pageTitle = "Full Catalog";

include("inc/header.php"); ?>

<div class="section page">
    <h1>Full Catalog</h1>
</div>

<?php include("inc/footer.php"); ?>