<?php 
$pageTitle = "Full Catalog";

if (isset($_GET["cat"])) {
    if ($_GET["cat"] == "books") {
        $pageTitle = "Books";
    } else if ($_GET["cat"] == "movies") {
        $pageTitle = "Movies";
    } else if ($_GET["cat"] == "music") {
        $pageTitle = "Music";
    }
}

include("inc/header.php"); ?>

<div class="section catalog page">
    <h1><?php echo $pageTitle; ?></h1>
</div>

<?php include("inc/footer.php"); ?>