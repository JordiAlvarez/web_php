<?php 
$pageTitle = "Suggest a Media Item";

include("inc/header.php"); ?>

<div class="section page">
    <h1>Suggest a Media Item</h1>
</div>

<?php include("inc/footer.php"); ?>