</div><!-- end content -->

	<div class="footer">

		<div class="wrapper">

			<ul>		
				<li><a href="http://twitter.com/treehouse">Twitter</a></li>
				<li><a href="https://www.facebook.com/TeamTreehouse">Facebook</a></li>
			</ul>

			<p>&copy;<?php echo date("Y"); ?> Personal Media Library</p>

		</div>
	
	</div>

</body>
</html>